package com.example.myapplication;

public class Admin {
    private String codAdmin;

    public Admin(String codAdmin){
        this.codAdmin=codAdmin;
    }

    public String getCodAdmin() {
        return codAdmin;
    }

    public void setCodAdmin(String codAdmin) {
        this.codAdmin = codAdmin;
    }
}