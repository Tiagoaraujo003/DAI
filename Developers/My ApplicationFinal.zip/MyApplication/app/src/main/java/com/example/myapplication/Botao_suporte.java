package com.example.myapplication;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;


import androidx.appcompat.app.AppCompatActivity;

public class Botao_suporte extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.suporte);
    }

    public void irParaFaq(View view) {
        Intent intent = new Intent(this,Botao_faq.class);
        startActivity(intent);
    }

    public void irParaContactar(View view) {
        Intent intent = new Intent(this,Botao_contactar.class);
        startActivity(intent);
    }

    public void irParaFeedback(View view) {
        Intent intent = new Intent(this,Botao_feedback.class);
        startActivity(intent);
    }

    public void irParaRegras(View view) {
        Intent intent = new Intent(this,Botao_regras.class);
        startActivity(intent);
    }
}