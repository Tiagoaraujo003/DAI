package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Pagina_principal extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pagina_principal_activity);
    }
    public void irParaPontos(View view) {
        Intent intent = new Intent(this,Menu_pontos.class);
        startActivity(intent);
    }

    public void irParaMais(View view) {
        Intent intent = new Intent(this,Botao_mais.class);
        startActivity(intent);
    }

    public void irParaPremios(View view) {
        Intent intent = new Intent(this,Botao_premios.class);
        startActivity(intent);
    }

    public void irParaConta(View view) {
        Intent intent = new Intent(this,Botao_conta.class);
        startActivity(intent);
    }



}