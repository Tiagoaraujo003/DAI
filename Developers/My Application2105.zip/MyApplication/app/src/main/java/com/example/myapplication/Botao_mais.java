package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Botao_mais extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mais);
    }

    public void irParaNotificacoes(View view) {
        Intent intent = new Intent(this,Botao_notificacoes.class);
        startActivity(intent);
    }

    public void irParaSuporte(View view) {
        Intent intent = new Intent(this,Botao_suporte.class);
        startActivity(intent);
    }
    public void irParaHistorico(View view) {
        Intent intent = new Intent(this,Botao_historico.class);
        startActivity(intent);
    }
}
