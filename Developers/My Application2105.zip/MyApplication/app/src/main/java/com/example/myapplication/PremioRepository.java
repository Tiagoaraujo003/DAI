package com.example.myapplication;

import com.example.myapplication.Admin;
import com.example.myapplication.Premio;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PremioRepository extends JpaRepository<Premio, Long> {
    Optional<Premio> findByPremioId(Long Id);

}
