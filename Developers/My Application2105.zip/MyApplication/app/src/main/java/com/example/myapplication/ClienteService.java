package com.example.myapplication;

import android.graphics.Bitmap;
import android.graphics.Color;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.common.BitMatrix;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.*;

@Service
public class ClienteService {

    @Autowired
    private ClienteRepository clienteRepository;

    public boolean guardarCliente(Cliente cliente) {
        Cliente clienteSalvo = clienteRepository.save(cliente);
        return clienteSalvo != null;
    }

    public boolean clienteEncontrado(Cliente cliente) {
        Optional<Cliente> clienteOptional = clienteRepository.findById(cliente.getClienteId());
        return clienteOptional.isPresent();
    }

    public List<Cliente> imprimir() {
        return clienteRepository.findAll();
    }

    public boolean existeClienteCriado(Cliente cliente) {
        Optional<Cliente> clienteOptional = clienteRepository.findById(cliente.getClienteId());
        if (clienteOptional.isPresent()) {
            Cliente clienteNoBanco = clienteOptional.get();
            return clienteNoBanco.getEmail().equals(cliente.getEmail())
                    || clienteNoBanco.getNomeCliente().equals(cliente.getNomeCliente());
        } else {
            return false;
        }
    }

    public boolean loginCliente(Cliente cliente) {
        Optional<Cliente> clienteOptional = clienteRepository.findById(cliente.getClienteId());
        if (clienteOptional.isPresent()) {
            Cliente clienteNoBanco = clienteOptional.get();
            return clienteNoBanco.getEmail().equals(cliente.getEmail())
                    || clienteNoBanco.getPassword().equals(cliente.getPassword());
        } else {
            return false;
        }
    }

    public String criarCodigos() {
        String prefixo = "C";
        int maximo = 999999999;
        List<String> codigosGerados = new ArrayList<>();
        while (true) {
            int numeroAleatorio = new Random().nextInt(maximo) + 1;
            String novoCodigo = prefixo + String.format("%09d", numeroAleatorio);
            if (!codigosGerados.contains(novoCodigo)) {
                codigosGerados.add(novoCodigo);
                return novoCodigo;
            }
        }
    }

    public static byte[] gerarQRCode(Cliente cliente) {
        int largura = 300;
        int altura = 300;
        String formatoImagem = "png";
        Map<EncodeHintType, String> hints = new HashMap<>();
        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");

        try {
            QRCodeWriter qrWriter = new QRCodeWriter();
            String codigoCliente = cliente.getCodigoCliente();
            BitMatrix bitMatrix = qrWriter.encode(codigoCliente, BarcodeFormat.QR_CODE, largura, altura, hints);
            Bitmap bitmap = toBitmap(bitMatrix);
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
            return outputStream.toByteArray();
        } catch (WriterException e) {
            System.out.println("Erro ao gerar o QR code: " + e.getMessage());
            return null;
        }
    }

    private static Bitmap toBitmap(BitMatrix bitMatrix) {
        int width = bitMatrix.getWidth();
        int height = bitMatrix.getHeight();
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                bitmap.setPixel(x, y, bitMatrix.get(x, y) ? Color.BLACK : Color.WHITE);
            }
        }
        return bitmap;
    }

    public boolean editarCliente(Cliente editarcliente) {
        Optional<Cliente> clienteOptional = clienteRepository.findById(editarcliente.getClienteId());
        if (clienteOptional.isPresent()) {
            Cliente clienteNoBanco = clienteOptional.get();
            if (editarcliente.getNomeCliente() != null && !editarcliente.getNomeCliente().isEmpty()) {
                clienteNoBanco.setNomeCliente(editarcliente.getNomeCliente());
            }
            if (editarcliente.getPassword() != null && !editarcliente.getPassword().isEmpty()) {
                clienteNoBanco.setPassword(editarcliente.getPassword());
            }
            if (editarcliente.getDataNascimento() != null) {
                clienteNoBanco.setDataNascimento(editarcliente.getDataNascimento());
            }
            if (editarcliente.getGenero() != null && !editarcliente.getGenero().isEmpty()) {
                clienteNoBanco.setGenero(editarcliente.getGenero());
            }
            Cliente clienteEditado = clienteRepository.save(clienteNoBanco);
            return clienteEditado != null;
        } else {
            return false;
        }
    }

    public void adicionarPontos(Cliente cliente, Viagem viagem) {
        int pontosAtuais = cliente.getPontos();
        int novosPontos = pontosAtuais + viagem.getPontos();
        cliente.setPontos(novosPontos);
    }

    public void receberPremio(Cliente cliente, Premio premio) {
        List<Premio> premiosResgatados = cliente.getPremiosResgatados();
        premiosResgatados.add(premio);
        cliente.setPremiosResgatados(premiosResgatados);
        clienteRepository.save(cliente);
    }

    public int obterPontosDoCliente(Cliente cliente) {
        return cliente.getPontos();
    }

    public String obterCodigoDoCliente(Cliente cliente) {
        return cliente.getCodigoCliente();
    }

    public List<Viagem> listarViagensDoCliente(Cliente cliente) {
        Cliente clientenobanco = clienteRepository.findById(cliente.getClienteId())
                .orElseThrow(() -> new RuntimeException("Cliente não encontrado com ID: " + cliente.getClienteId()));
        return cliente.getHistoricoViagens();
    }

    public List<Premio> listarPremiosResgatadosDoCliente(Cliente cliente) {
        Cliente clientenobanco = clienteRepository.findById(cliente.getClienteId())
                .orElseThrow(() -> new RuntimeException("Cliente não encontrado com ID: " + cliente.getClienteId()));
        return cliente.getPremiosResgatados();
    }

    public boolean removerCliente(Cliente cliente) {
        Optional<Cliente> clienteParaRemover = clienteRepository.findById(cliente.getClienteId());
        if (clienteParaRemover.isPresent()) {
            clienteRepository.delete(clienteParaRemover.get());
            return true;
        }
        System.out.println("cliente não encontrado");
        return false;
    }
}