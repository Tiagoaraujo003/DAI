package com.example.myapplication;

import com.example.myapplication.Viagem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ViagemRepository extends JpaRepository<Viagem,Long> {
}
