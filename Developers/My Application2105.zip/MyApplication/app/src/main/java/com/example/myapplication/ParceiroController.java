package com.example.myapplication;

import com.example.myapplication.Admin;
import com.example.myapplication.Parceiro;
import com.example.myapplication.Premio;
import com.example.myapplication.ParceiroRepository;
import com.example.myapplication.ClienteService;
import com.example.myapplication.ParceiroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/Parceiro")
@CrossOrigin
public class ParceiroController {
    @Autowired
    ParceiroService parceiroService;

    @GetMapping("/verificar")
    public boolean verificarParceiro(Parceiro parceiro){
        return parceiroService.verificarParceiro(parceiro);
    }

    @PostMapping("/adicionarParceiro")
    public ResponseEntity<Object> adicionarParceiro(Parceiro parceiro){
        if(parceiroService.guardarParceiro(parceiro)){
            return ResponseEntity.ok().body("Parceiro registrado com sucesso.");
        }else{
            return ResponseEntity.badRequest().body("Falha ao registrar o Parceiro.");
        }
    }

    @DeleteMapping("/removerparceiro")
    public ResponseEntity<String> removerParceiro(@RequestBody Parceiro parceiro) {
        boolean removido = parceiroService.removerParceiro(parceiro);
        if (removido) {
            return ResponseEntity.ok("Parceiro removido com sucesso");
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
