package com.example.myapplication;

import com.example.myapplication.Cliente;
import com.example.myapplication.Viagem;
import com.example.myapplication.ClienteRepository;
import com.example.myapplication.ClienteService;
import com.example.myapplication.ViagemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/Viagem")
@CrossOrigin

public class ViagemController {
    @Autowired
    ClienteService clienteService;
    @Autowired
    ViagemService viagemService;

    @PostMapping("/viagem/validar")
    public void validarViagem(@RequestBody Cliente cliente) {
        viagemService.validarViagem(cliente);
    }

    @PostMapping("/viagem/pontos")
    public ResponseEntity<String> definirPontosViagem(@RequestParam int pontos) {
        viagemService.definirPontosDaViagem(pontos);

        return ResponseEntity.ok("Pontos da viagem definidos como: " + pontos);
    }
}
