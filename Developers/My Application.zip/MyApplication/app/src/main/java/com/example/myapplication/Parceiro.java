package com.example.myapplication;

public class Parceiro {
    private String nomeParceiro;

    public Parceiro(String nomeParceiro){
        this.nomeParceiro=nomeParceiro;
    }

    public String getNomeParceiro() {
        return nomeParceiro;
    }

    public void setNomeParceiro(String nomeParceiro) {
        this.nomeParceiro = nomeParceiro;
    }
}