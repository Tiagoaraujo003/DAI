package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Menu_login extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    // Método chamado quando o botão "Mover" é clicado
    public void irParaRegisto(View view) {
        Intent intent = new Intent(this, Botao_registar.class);
        startActivity(intent);
    }

    public void irParaMenuP (View view){
        Intent intent= new Intent(this,Pagina_principal.class);
        startActivity(intent);
    }
}