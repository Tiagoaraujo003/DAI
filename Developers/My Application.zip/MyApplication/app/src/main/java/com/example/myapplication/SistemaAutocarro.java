package com.example.myapplication;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.util.Log;
import com.google.zxing.LuminanceSource;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.Result;
import com.google.zxing.common.HybridBinarizer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SistemaAutocarro {


    public class BitmapLuminanceSource extends LuminanceSource {

        private final byte[] luminances;

        public BitmapLuminanceSource(Bitmap bitmap) {
            super(bitmap.getWidth(), bitmap.getHeight());

            int width = bitmap.getWidth();
            int height = bitmap.getHeight();
            int[] pixels = new int[width * height];
            bitmap.getPixels(pixels, 0, width, 0, 0, width, height);

            luminances = new byte[width * height];
            for (int y = 0; y < height; y++) {
                int offset = y * width;
                for (int x = 0; x < width; x++) {
                    int pixel = pixels[offset + x];
                    int r = (pixel >> 16) & 0xff;
                    int g = (pixel >> 8) & 0xff;
                    int b = pixel & 0xff;
                    // Convertendo para escala de cinza usando a média dos canais RGB
                    int luminance = (r + g + b) / 3;
                    luminances[offset + x] = (byte) luminance;
                }
            }
        }

        @Override
        public byte[] getRow(int y, byte[] row) {
            System.arraycopy(luminances, y * getWidth(), row, 0, getWidth());
            return row;
        }

        @Override
        public byte[] getMatrix() {
            return luminances;
        }
    }

    private ListaCliente listaClientes;
    private int pontosPorViagem; // Defina a quantidade de pontos a serem adicionados por viagem

    public SistemaAutocarro(ListaCliente listaClientes) {
        this.listaClientes = listaClientes;
    }

    public int getPontosPorViagem() {
        return pontosPorViagem;
    }

    public void setPontosPorViagem(int pontosPorViagem) {
        this.pontosPorViagem = pontosPorViagem;
        Log.d("SistemaAutocarro", "Quantidade de pontos por viagem atualizada para: " + pontosPorViagem);
    }

    public void validarViagem(String codigoCliente) {
        Cliente cliente = listaClientes.encontrarClientePorCodigo(codigoCliente);
        if (cliente != null) {
            // Se o cliente existir, adiciona os pontos à sua conta
            cliente.adicionarPontos(pontosPorViagem);
            Log.d("SistemaAutocarro", "Viagem validada para o cliente " + cliente.getNomeC() + ". " + pontosPorViagem + " pontos adicionados à conta.");
        } else {
            Log.d("SistemaAutocarro", "Cliente com código " + codigoCliente + " não encontrado.");
        }
    }

    public void validarViagemPorQRCode(String caminhoImagemQRCode) {
        try {
            FileInputStream inputStream = new FileInputStream(caminhoImagemQRCode);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);

            // Convertendo a imagem para escala de cinza
            Bitmap grayBitmap = toGrayscale(bitmap);

            // Criando uma instância de BinaryBitmap diretamente da imagem Bitmap
            BinaryBitmap binaryBitmap = new BinaryBitmap(new HybridBinarizer(new BitmapLuminanceSource(grayBitmap)));

            // Decodificando o código QR
            Result resultado = new MultiFormatReader().decode(binaryBitmap);
            String codigoCliente = resultado.getText();
            validarViagem(codigoCliente);
        } catch (FileNotFoundException e) {
            Log.e("SistemaAutocarro", "Arquivo não encontrado: " + e.getMessage());
        } catch (Exception e) {
            Log.e("SistemaAutocarro", "Erro ao ler o QR code: " + e.getMessage());
        }
    }

    // Método para converter uma imagem para escala de cinza
    private Bitmap toGrayscale(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();

        // Criando um novo bitmap em escala de cinza
        Bitmap grayscaleBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);

        // Iterando sobre todos os pixels da imagem original e definindo os pixels do novo bitmap em escala de cinza
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                int pixel = bitmap.getPixel(x, y);
                int grayPixel = (int) (0.299 * Color.red(pixel) + 0.587 * Color.green(pixel) + 0.114 * Color.blue(pixel));
                int gray = Color.rgb(grayPixel, grayPixel, grayPixel);
                grayscaleBitmap.setPixel(x, y, gray);
            }
        }
        return grayscaleBitmap;
    }
}
