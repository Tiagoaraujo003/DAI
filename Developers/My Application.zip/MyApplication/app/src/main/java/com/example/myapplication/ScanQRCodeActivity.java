package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;




public class ScanQRCodeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_qrcode); // Certifique-se de ter um layout `activity_scan_qrcode`

        // Configuração personalizada do scanner
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setOrientationLocked(false);
        integrator.setBeepEnabled(true);
        integrator.setPrompt("Scan a QR code");
        integrator.initiateScan();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() == null) {
                Toast.makeText(this, "Scan Cancelado", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Código Scaneado: " + result.getContents(), Toast.LENGTH_LONG).show();
                handleScanResult(result.getContents()); // Adicionando o método para processar o resultado
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }


    // Método para tratar o resultado do escaneamento
    private void handleScanResult(String scanResult) {

        Intent intent = new Intent(this, ResultActivity.class);
        intent.putExtra("qr_result", scanResult);
        startActivity(intent);
    }
}
