package com.example.demo.model.support;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@DiscriminatorValue("FeedBack")
public class FeedBack extends SupportRequest{
    @Column(name = "feedback" , nullable = false)
    private String feedback;
}