package com.example.demo.service;

import com.example.demo.model.Admin;
import com.example.demo.model.Parceiro;
import com.example.demo.model.Premio;
import com.example.demo.repository.ParceiroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ParceiroService {
    @Autowired
    ParceiroRepository parceiroRepository;
    public boolean verificarParceiro(Parceiro parceiro){
        Optional<Parceiro> parceiroOptional = parceiroRepository.findById(parceiro.getParceiroID());
        if (parceiroOptional.isPresent()) {
            Parceiro parceiroNoBanco = parceiroOptional.get();
            return parceiroNoBanco.getPinParceiro() == (parceiro.getPinParceiro());
        } else {
            return false; // Se o parceiro não existir no banco, retorna false
        }
    }

    public boolean guardarParceiro(Parceiro parceiro){
        Parceiro parceirosalvo = new Parceiro();
        parceirosalvo.setNomeParceiro(parceiro.getNomeParceiro());
        parceirosalvo.setPinParceiro(parceiro.getPinParceiro());
        Parceiro adminSalvo = parceiroRepository.save(parceirosalvo);
        return adminSalvo != null;
    }

    public boolean removerParceiro(Parceiro parceiro){
        Optional<Parceiro> parceiroParaRemover = parceiroRepository.findById(parceiro.getParceiroID());

        if(parceiroParaRemover.isPresent()){
            parceiroRepository.delete(parceiroParaRemover.get());
            return true;
        }
        System.out.println("Premio não encontrado");
        return false;

    }
}
