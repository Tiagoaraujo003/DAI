package com.example.demo.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name= "Premios")
public class Premio {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "premioid" , nullable = false)
    private int premioId;
    @Column(name = "NomePremio" , nullable = false)
    private String NomePremio;
    @Column(name = "Descricao" , nullable = false)
    private String Descricao;
    @Column(name = "Pontos_pr" , nullable = false)
    private int Pontos_pr;
}
