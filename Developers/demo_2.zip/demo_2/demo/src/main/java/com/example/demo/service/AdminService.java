package com.example.demo.service;

import com.example.demo.model.Admin;
import com.example.demo.model.Cliente;
import com.example.demo.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdminService {
    @Autowired
    AdminRepository adminRepository;

    public List<Admin> imprimir(){
        return adminRepository.findAll();
    }
    public boolean verificarAdmin(Admin admin){
        Optional<Admin> adminOptional = adminRepository.findById(admin.getAdminID());
        if (adminOptional.isPresent()) {
            Admin adminNoBanco = adminOptional.get();
            return adminNoBanco.getPinAdmin() == (admin.getPinAdmin());
        } else {
            return false; // Se o admin não existir no banco, retorna false

        }
    }

    public boolean editarAdmin( Admin editarAdmin){
        Optional<Admin> adminOptional = adminRepository.findById(editarAdmin.getAdminID());

        if (adminOptional.isPresent()) {
            Admin adminNoBanco = adminOptional.get();

            // Verificar e atualizar cada campo apenas se for fornecido um novo valor
            if (editarAdmin.getPinAdmin() != ' ' && editarAdmin.getPinAdmin() < 0) {
                adminNoBanco.setAdminID(editarAdmin.getAdminID());
            }
            if (editarAdmin.getEmailAdmin() != null && !editarAdmin.getEmailAdmin().isEmpty()) {
                adminNoBanco.setEmailAdmin(adminNoBanco.getEmailAdmin());
            }


            // Salvar o cliente atualizado no banco de dados
            Admin adminEditado = adminRepository.save(adminNoBanco);

            return adminEditado != null;
        } else {
            return false; // Cliente não encontrado no banco de dados
        }

    }

    public boolean guardarAdmin(Admin admin){
        Admin adminsalvo = new Admin();
        adminsalvo.setEmailAdmin(admin.getEmailAdmin());
        adminsalvo.setPinAdmin(admin.getPinAdmin());
        Admin adminSalvo = adminRepository.save(adminsalvo);
        return adminSalvo != null;
    }
}
