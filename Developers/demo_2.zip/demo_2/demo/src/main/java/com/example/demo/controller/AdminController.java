package com.example.demo.controller;

import com.example.demo.model.Admin;
import com.example.demo.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin
public class AdminController {

    @Autowired
    private AdminService adminService;

    @PostMapping("/verificar")
    public ResponseEntity<Boolean> verificar(@RequestBody Admin admin) {
        boolean isValid = adminService.verificarAdmin(admin);
        return ResponseEntity.ok(isValid);
    }

    @PostMapping("/adicionar")
    public ResponseEntity<String> adicionarAdmin(@RequestBody Admin admin) {
        if (adminService.guardarAdmin(admin)) {
            return ResponseEntity.ok("Admin registrado com sucesso.");
        } else {
            return ResponseEntity.badRequest().body("Falha ao registrar o Admin.");
        }
    }
}
