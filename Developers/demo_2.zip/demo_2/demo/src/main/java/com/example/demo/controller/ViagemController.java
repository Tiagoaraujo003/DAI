package com.example.demo.controller;

import com.example.demo.model.Cliente;
import com.example.demo.model.Viagem;
import com.example.demo.repository.ClienteRepository;
import com.example.demo.service.ClienteService;
import com.example.demo.service.ViagemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@RestController
@RequestMapping("/Viagem")
@CrossOrigin

public class ViagemController {
    @Autowired
    ClienteService clienteService;
    @Autowired
    ViagemService viagemService;

    @PostMapping("/viagem/validarporcodigo")
    public void validarViagem(@RequestBody Cliente cliente) {
        viagemService.validarViagem(cliente);
    }

    @PostMapping("/viagem/validarporqrcode")
    public ResponseEntity<String> validarViagem(@RequestParam("qrCode") MultipartFile qrCodeFile) {
        try {

            File tempFile = File.createTempFile("qrCode-", ".png");
            qrCodeFile.transferTo(tempFile);

            viagemService.validarViagem(tempFile.getAbsolutePath());

            tempFile.delete();

            return ResponseEntity.ok("Viagem validada com sucesso.");
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro ao processar o QR code.");
        } catch (RuntimeException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @PostMapping("/viagem/pontos")
    public ResponseEntity<String> definirPontosViagem(@RequestParam int pontos) {
        viagemService.definirPontosDaViagem(pontos);

        return ResponseEntity.ok("Pontos da viagem definidos como: " + pontos);
    }
}
