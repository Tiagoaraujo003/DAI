package com.example.demo.model.support;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@DiscriminatorValue("ContactarSuporte")
public class ContactarSuporte extends SupportRequest{
    @Column(name = "perguntasuporte" , nullable = false)
    private String pergunta;

}
