package com.example.demo.repository.suportreppository;

import com.example.demo.model.support.ContactarSuporte;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContactarSuporteRepository extends JpaRepository<ContactarSuporte, Integer> {
}
