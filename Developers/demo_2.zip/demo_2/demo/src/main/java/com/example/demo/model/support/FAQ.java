package com.example.demo.model.support;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@DiscriminatorValue("FAQ")
public class FAQ extends SupportRequest{
    @Column(name = "perguntaFAQ" , nullable = false)
    private String pergunta;
    @Column(name = "responderFAQ" , nullable = false)
    private String resposta;
}