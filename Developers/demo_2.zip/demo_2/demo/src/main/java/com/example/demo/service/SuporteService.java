package com.example.demo.service;

import com.example.demo.model.support.ContactarSuporte;
import com.example.demo.model.support.FAQ;
import com.example.demo.model.support.FeedBack;
import com.example.demo.repository.suportreppository.ContactarSuporteRepository;
import com.example.demo.repository.suportreppository.FAQRepository;
import com.example.demo.repository.suportreppository.FeedBackRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
public class SuporteService {
    @Autowired
    FAQRepository faqRepository;

   @Autowired
   FeedBackRepository feedBackRepository;

   @Autowired
   ContactarSuporteRepository contactarSuporteRepository;

    public List<FAQ> ListaFAQs() {
        return faqRepository.findAll();
    }

    public FAQ adicionarFAQ(FAQ faq) {
        return faqRepository.save(faq);
    }

    public List<FeedBack> ListaFeedbacks() {
        return feedBackRepository.findAll();
    }

    public FeedBack adicionarFeedback(FeedBack feedback) {
        return feedBackRepository.save(feedback);
    }

    public List<ContactarSuporte> ListaContactarSuporte() {
        return contactarSuporteRepository.findAll();
    }

    public ContactarSuporte adicionarContactSupport(ContactarSuporte contactarSuporte) {
        return contactarSuporteRepository.save(contactarSuporte);
    }
}

