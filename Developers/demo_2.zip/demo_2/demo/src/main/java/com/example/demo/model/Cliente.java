package com.example.demo.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name= "Cliente_da_TUBeneficios")
public class Cliente {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cliente_id" , nullable = false)
    private int ClienteId;
    @Column(name = "NomeCliente" , nullable = false)
    private String NomeCliente;
    @Column(name = "Email" , nullable = false)
    private String Email;
    @Column(name = "Password" , nullable = false)
    private String Password;
    @Column(name = "DataNascimento" , nullable = false)
    private LocalDate DataNascimento;
    @Column(name = "Genero" , nullable = false)
    private String Genero;
    @Column(name = "CodigoCliente")
    private String CodigoCliente;
    @Column(name = "Pontos")
    private int Pontos;
    @Column(name = "codigoQR")
    private byte[] codigoQR;

    @ManyToMany
    @JoinTable(
            name = "CLIENTE_PREMIO", joinColumns = @JoinColumn(name = "cliente_id"),
            inverseJoinColumns = @JoinColumn(name = "PremioId")
    )
    private List<Premio> premiosResgatados;

    @OneToMany(mappedBy = "cliente")
    private List<Viagem> historicoViagens;

}
