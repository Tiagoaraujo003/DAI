package com.example.demo.repository.suportreppository;

import com.example.demo.model.support.FAQ;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FAQRepository extends JpaRepository<FAQ, Integer> {
}