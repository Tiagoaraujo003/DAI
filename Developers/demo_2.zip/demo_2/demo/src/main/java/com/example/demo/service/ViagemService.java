package com.example.demo.service;

import com.example.demo.model.Cliente;
import com.example.demo.model.Viagem;
import com.example.demo.repository.ClienteRepository;


import com.google.zxing.*;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Optional;

@Service
public class ViagemService {

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private ClienteService clienteService;

    private int pontosDaViagem;

    public void definirPontosDaViagem(int pontos) {
        this.pontosDaViagem = pontos;
        System.out.println("Pontos da viagem definidos como: " + pontos);
    }

    public void validarViagem(Cliente cliente) {
        int clienteId = cliente.getClienteId();
        Cliente clienteEncontrado = clienteRepository.findById(clienteId)
                .orElseThrow(() -> new RuntimeException("Cliente não encontrado com ID: " + clienteId));

        LocalDate dataDaViagem = LocalDate.now();
        Viagem viagem = criarViagem(clienteEncontrado, dataDaViagem);

        // Adicionar a viagem ao histórico de viagens do cliente
        clienteEncontrado.getHistoricoViagens().add(viagem);

        // Atualizar os pontos do cliente e salvar no repositório
        clienteService.adicionarPontos(clienteEncontrado, viagem);
        clienteRepository.save(clienteEncontrado);

        System.out.println("Viagem validada para o cliente " + clienteEncontrado.getNomeCliente()
                + ". " + viagem.getPontos() + " pontos adicio" +
                "nados à conta.");
    }

    public void validarViagem(String qrCodeFilePath) {
        try {
            // Ler o QR code da imagem
            BufferedImage bufferedImage = ImageIO.read(new File(qrCodeFilePath));
            LuminanceSource source = new BufferedImageLuminanceSource(bufferedImage);
            BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));

            // Decodificar o QR code
            Result result = new MultiFormatReader().decode(bitmap);
            String clienteIdStr = result.getText();
            int clienteId = Integer.parseInt(clienteIdStr);

            // Buscar o cliente no repositório
            Cliente clienteEncontrado = clienteRepository.findById(clienteId)
                    .orElseThrow(() -> new RuntimeException("Cliente não encontrado com ID: " + clienteId));

            LocalDate dataDaViagem = LocalDate.now();
            Viagem viagem = criarViagem(clienteEncontrado, dataDaViagem);

            // Adicionar a viagem ao histórico de viagens do cliente
            clienteEncontrado.getHistoricoViagens().add(viagem);

            // Atualizar os pontos do cliente e salvar no repositório
            clienteService.adicionarPontos(clienteEncontrado, viagem);
            clienteRepository.save(clienteEncontrado);

            System.out.println("Viagem validada para o cliente " + clienteEncontrado.getNomeCliente()
                    + ". " + viagem.getPontos() + " pontos adicionados à conta.");
        } catch (IOException | NotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException("Erro ao ler o QR code: " + e.getMessage());
            }
    }

    public Viagem criarViagem(Cliente cliente,LocalDate horarioViagem) {
        return new Viagem(pontosDaViagem, horarioViagem,cliente);
    }
}
