package com.example.demo.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name= "Administrador_daTUBeneficios")
public class Admin {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "AdminID" , nullable = false)
    private int AdminID;
    @Column(name = "PinAdmin" , nullable = false)
    private int PinAdmin;
    @Column(name = "emailAdmin" , nullable = false)
    private String emailAdmin;
}