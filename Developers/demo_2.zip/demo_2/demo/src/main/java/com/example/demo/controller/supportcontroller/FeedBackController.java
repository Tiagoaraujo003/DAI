package com.example.demo.controller.supportcontroller;
import com.example.demo.model.support.FeedBack;
import com.example.demo.service.SuporteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/feedbacks")
public class FeedBackController {

    @Autowired
    private SuporteService suporteService;

    @GetMapping("listafeedback")
    public List<FeedBack> getAllFeedbacks() {
        return suporteService.ListaFeedbacks();
    }

    @PostMapping("adicionarfeedback")
    public FeedBack addFeedback(@RequestBody FeedBack feedback) {
        return suporteService.adicionarFeedback(feedback);
    }
}