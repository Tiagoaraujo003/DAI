package com.example.demo.repository.suportreppository;

import com.example.demo.model.support.FeedBack;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FeedBackRepository extends JpaRepository<FeedBack, Integer> {
}
