package com.example.demo.controller.supportcontroller;

import com.example.demo.model.support.FAQ;
import com.example.demo.service.SuporteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/faqs")
public class FAQController {

    @Autowired
    private SuporteService suporteService;

    @GetMapping("/listarfaqs")
    public List<FAQ> ListaFAQs() {
        return suporteService.ListaFAQs();
    }

    @PostMapping("/adicionarfaqs")
    public FAQ adicionarFAQ(@RequestBody FAQ faq) {
        return suporteService.adicionarFAQ(faq);
    }
}