package com.example.demo.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name= "Parceiro_daTUBeneficios")
public class Parceiro {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ParceiroID" , nullable = false)
    private int ParceiroID;
    @Column(name = "NomeParceiro" , nullable = false)
    private String NomeParceiro;
    @Column(name = "PinParceiro" , nullable = false)
    private int PinParceiro;
}
